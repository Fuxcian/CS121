package week12.setsAndIterators;

public class Main {
    public static void main(String[] args){
        RestaurantSet tableList = new RestaurantSet();

        tableList.addTables();
        tableList.displayTables();
    }
}
